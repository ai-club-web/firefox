#!/bin/bash

export DISPLAY=:99

# 1. Setup the VNC Password
mkdir -p $HOME/.vnc
x11vnc -storepasswd "$VNC_PASSWORD" $HOME/.vnc/passwd

# 2. Configure Tor for fast, automatic IP rotation (Round-Robin effect)
echo "Configuring Tor..."
mkdir -p $HOME/tor_data
chmod 700 $HOME/tor_data

cat <<EOF > $HOME/torrc
DataDirectory $HOME/tor_data
SocksPort 127.0.0.1:9050
# Forces Tor to build a new circuit (new IP) every 10 seconds
MaxCircuitDirtiness 10
NewCircuitPeriod 10
EOF

# 3. Start Tor in the background
echo "Starting Tor..."
tor -f $HOME/torrc &

# Give Tor time to connect to the network
echo "Waiting 8 seconds for Tor circuits to build..."
sleep 8

# 4. Start the Virtual X Server (Xvfb)
Xvfb :99 -screen 0 1920x1080x16 -nolisten tcp &
sleep 2

# 5. Start Openbox window manager
openbox-session &

# 6. Start the VNC Server
x11vnc -display :99 -rfbauth $HOME/.vnc/passwd -forever -shared -bg -localhost -xkb
sleep 1

# 7. Start noVNC (Web GUI gateway)
websockify --web /usr/share/novnc 8080 localhost:5900 &

# 8. Start Firefox in an infinite loop
echo "Starting Firefox..."
while true; do
    firefox-esr --new-instance
    sleep 1
done